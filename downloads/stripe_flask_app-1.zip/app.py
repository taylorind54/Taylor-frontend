from flask import Flask, request, jsonify, render_template
import stripe
import os

app = Flask(__name__)
stripe.api_key = "sk_test_your_secret_key_here"  # Replace with your secret key

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/create-customer", methods=["POST"])
def create_customer():
    data = request.get_json()
    customer = stripe.Customer.create(
        email=data["email"],
        name=data.get("name", ""),
    )
    setup_intent = stripe.SetupIntent.create(
        customer=customer.id,
        payment_method_types=["card"]
    )
    return jsonify({
        "clientSecret": setup_intent.client_secret,
        "customerId": customer.id
    })

@app.route("/create-subscription", methods=["POST"])
def create_subscription():
    data = request.get_json()
    customer_id = data["customerId"]
    payment_method_id = data["paymentMethodId"]

    # Attach the payment method to the customer
    stripe.PaymentMethod.attach(
        payment_method_id,
        customer=customer_id,
    )

    # Set it as default
    stripe.Customer.modify(
        customer_id,
        invoice_settings={"default_payment_method": payment_method_id},
    )

    # Create subscription
    subscription = stripe.Subscription.create(
        customer=customer_id,
        items=[{"price": "price_your_stripe_price_id"}],  # Replace with your price ID
        trial_period_days=0
    )

    return jsonify(subscription)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
